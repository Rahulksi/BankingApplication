﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BankingApplication.Models;

namespace BankingApplication.Controllers
{
    public class TransfersController : Controller
    {
        private readonly BankAccountDbContext _context;

        public TransfersController(BankAccountDbContext context)
        {
            _context = context;
        }

        // GET: Transfers
        public async Task<IActionResult> Index()
        {
            ViewData["FromAccount"] = new SelectList(_context.Accounts, "AccountName", "AccountName");
            ViewData["ToAccount"] = new SelectList(_context.Accounts, "AccountName", "AccountName");
            return View();
        }

        // POST: Transfers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FromAccount,ToAccount,AmountDebited")] Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                var fromAccount = await _context.Accounts.FindAsync(transaction.FromAccount);
                if (fromAccount.Balance < transaction.AmountDebited) 
                {
                    TempData["InsufficientBalanceMessage"] = $"Insufficient Balance: {fromAccount.Balance}";
                    return RedirectToAction(nameof(Index));
                }
                var toAccount = await _context.Accounts.FindAsync(transaction.ToAccount);
                transaction.FromAccountBalance = fromAccount.Balance;
                transaction.ToAccountBalance = toAccount.Balance;
                _context.Add(transaction);
                fromAccount.Balance = fromAccount.Balance - transaction.AmountDebited;
                toAccount.Balance = toAccount.Balance + transaction.AmountDebited;
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index), "Transactions");
            }
            ViewData["FromAccount"] = new SelectList(_context.Accounts, "AccountName", "AccountName", transaction.FromAccount);
            ViewData["ToAccount"] = new SelectList(_context.Accounts, "AccountName", "AccountName", transaction.ToAccount);
            return RedirectToAction(nameof(Index)); ;
        }
    }
}
