﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BankingApplication.Models;

public partial class BankAccountDbContext : DbContext
{
    public BankAccountDbContext()
    {
    }

    public BankAccountDbContext(DbContextOptions<BankAccountDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Account> Accounts { get; set; }

    public virtual DbSet<Transaction> Transactions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Account>(entity =>
        {
            entity.HasKey(e => e.AccountName).HasName("PK__Accounts__406E0D2F5376AD52");

            entity.Property(e => e.AccountName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Balance).HasColumnType("decimal(10, 2)");
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Transact__3214EC073ABFCFEF");

            entity.Property(e => e.AmountDebited).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.FromAccount)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FromAccountBalance).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.ToAccount)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ToAccountBalance).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.TransactionTime)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
