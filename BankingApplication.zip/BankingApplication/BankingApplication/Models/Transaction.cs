﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BankingApplication.Models;

public partial class Transaction
{
    public int Id { get; set; }

    public string FromAccount { get; set; }

    public string ToAccount { get; set; }

    public DateTime TransactionTime { get; set; }

    [Range(1, 10000)]
    public decimal AmountDebited { get; set; }

    public decimal FromAccountBalance { get; set; }

    public decimal ToAccountBalance { get; set; }
}
