﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BankingApplication.Models;

public partial class Account
{
    [Required]
    public string AccountName { get; set; }

    public decimal Balance { get; set; }
}
